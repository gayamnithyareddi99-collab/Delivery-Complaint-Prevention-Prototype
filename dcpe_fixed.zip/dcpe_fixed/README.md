# DCPE — Delivery Complaint Prevention Engine
## Deployment Guide — AI Features Setup

---

## ✅ OPTION 1: Open inside Claude.ai (Zero Setup — Recommended)

Just open `index.html` as an artifact inside **claude.ai**.
The AI features work automatically — Claude.ai proxies the API calls for you.
**No API key needed. No server needed.**

---

## ✅ OPTION 2: Deploy to Netlify (Free, 5 minutes)

### Step 1 — Get a free Anthropic API key
1. Go to **https://console.anthropic.com**
2. Sign up free → go to **API Keys** → click **Create Key**
3. Copy your key (starts with `sk-ant-api...`)

### Step 2 — Deploy to Netlify
1. Go to **https://netlify.com** → Sign up free
2. Click **"Add new site"** → **"Deploy manually"**
3. Drag and drop this entire folder (containing `index.html`, `netlify.toml`, `netlify/` folder)
4. Netlify will deploy in ~30 seconds

### Step 3 — Add your API key
1. In Netlify dashboard → your site → **Site configuration** → **Environment variables**
2. Click **"Add a variable"**
3. Key: `ANTHROPIC_API_KEY`  Value: `sk-ant-api...` (your key from Step 1)
4. Click **Save** → go to **Deploys** → click **"Trigger deploy"** → **"Deploy site"**

### Done! 🎉
Your site is live at `https://your-site-name.netlify.app` with full AI features.

---

## ✅ OPTION 3: Deploy to Vercel (Free, 5 minutes)

### Step 1 — Get a free Anthropic API key (same as above)

### Step 2 — Deploy to Vercel
1. Go to **https://vercel.com** → Sign up free with GitHub
2. Click **"Add New Project"** → **"Import"** (or drag and drop)
3. Upload this folder

### Step 3 — Add your API key
1. In Vercel dashboard → your project → **Settings** → **Environment Variables**
2. Name: `ANTHROPIC_API_KEY`  Value: `sk-ant-api...`
3. Click **Save** → **Redeploy**

---

## ✅ OPTION 4: Any Static Host (GitHub Pages, etc.) — Enter Key in Browser

If deploying to a pure static host with no serverless functions:
1. Open your deployed site
2. Click any AI button (e.g. "Analyse Order Risk")
3. A prompt will appear asking for your Anthropic API key
4. Enter your key — it's stored only in your browser session (never sent anywhere except Anthropic)

---

## File Structure

```
index.html                    ← Main site (single file, all pages)
netlify.toml                  ← Netlify config (routes /api/ai to function)
netlify/
  functions/
    ai.js                     ← Netlify serverless AI proxy
api/
  ai.js                       ← Vercel serverless AI proxy
README.md                     ← This file
```

---

## How the AI Works

The site uses **Claude Sonnet** (Anthropic) for 8 AI features:
1. **Order Forensic Analysis** — click any order row
2. **Risk Simulator** — configure order parameters
3. **Fingerprint Engine** — generate risk fingerprints
4. **Forensics Lab** — attribution analysis
5. **Dispute Generator** — evidence bundles
6. **OLM Query** — query learned patterns
7. **AI Advisor Chat** — multi-turn operations chat
8. **Integration Advisor** — tech stack recommendations

The AI call chain (tries each in order):
1. Direct to `api.anthropic.com` (works in Claude.ai)
2. `/api/ai` → your serverless function (works on Netlify/Vercel)
3. `corsproxy.io` CORS proxy (fallback)
4. Browser prompt for API key (last resort)

---

## Cost Estimate

Anthropic Claude Sonnet pricing (as of 2026):
- ~$3 per million input tokens
- ~$15 per million output tokens
- Each AI button click: ~500-1500 tokens = ~$0.001-0.003 per click
- **100 AI calls/day ≈ $0.10-0.30/day**

Free tier: Anthropic gives free credits on signup.

---

*DCPE — Delivery Complaint Prevention Engine | Founded by Hardik Badhwar | © 2026*
